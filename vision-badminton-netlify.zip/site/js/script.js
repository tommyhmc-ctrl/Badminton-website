const navToggle = document.querySelector(".nav-toggle");
const navLinks = document.querySelector(".nav-links");
const page = document.body.dataset.page;
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const announcementConfig = {
  title: "Club Announcement",
  tag: "Important Update",
  body: [
    "Use this popup for promotions, holiday hours, tournament notices, clinic registration windows, or urgent club updates.",
    "Right now it is set up as a reusable announcement block that appears when a visitor opens any page on the site."
  ],
  primaryLabel: "View Events",
  primaryHref: "events.html",
  secondaryLabel: "Close",
};

if (page) {
  document.querySelector(`[data-nav="${page}"]`)?.classList.add("is-active");
}

function closeNav() {
  if (navToggle) navToggle.setAttribute("aria-expanded", "false");
  if (navLinks) navLinks.classList.remove("open");
  document.querySelectorAll(".nav-dropdown").forEach((d) => d.classList.remove("dropdown-open"));
}

if (navToggle && navLinks) {
  navToggle.addEventListener("click", () => {
    const expanded = navToggle.getAttribute("aria-expanded") === "true";
    navToggle.setAttribute("aria-expanded", String(!expanded));
    navLinks.classList.toggle("open", !expanded);
    if (expanded) {
      // Nav just closed — reset all dropdowns
      document.querySelectorAll(".nav-dropdown").forEach((d) => d.classList.remove("dropdown-open"));
    }
  });

  // Close nav on non-dropdown link clicks
  navLinks.querySelectorAll("a").forEach((link) => {
    const isDropdownTrigger = link.parentElement.classList.contains("nav-dropdown");
    if (isDropdownTrigger) return;
    link.addEventListener("click", closeNav);
  });
}

// Mobile dropdown: tap trigger to expand/collapse submenu
document.querySelectorAll(".nav-dropdown > a").forEach((trigger) => {
  trigger.addEventListener("click", (e) => {
    if (window.innerWidth > 860) return;
    const dropdown = trigger.closest(".nav-dropdown");
    const isOpen = dropdown.classList.contains("dropdown-open");
    document.querySelectorAll(".nav-dropdown").forEach((d) => d.classList.remove("dropdown-open"));
    if (!isOpen) {
      e.preventDefault();
      dropdown.classList.add("dropdown-open");
    }
  });
});

// Close nav when a submenu item is tapped
document.querySelectorAll(".nav-dropdown-menu a").forEach((link) => {
  link.addEventListener("click", closeNav);
});

document.querySelectorAll("[data-form]").forEach((form) => {
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const success = form.querySelector(".form-success");
    if (success) {
      success.hidden = false;
    }
    form.reset();
  });
});

document.querySelectorAll("[data-external-form]").forEach((form) => {
  form.addEventListener("submit", (event) => {
    const action = form.getAttribute("action") || "";
    if (action.includes("your-form-id")) {
      event.preventDefault();
      const success = form.querySelector(".form-success");
      if (success) {
        success.hidden = false;
      }
    }
  });
});

if (!document.querySelector(".page-transition")) {
  const transitionLayer = document.createElement("div");
  transitionLayer.className = "page-transition";
  document.body.appendChild(transitionLayer);
}

if (page === "pickleball" && !document.querySelector(".announcement-overlay")) {
  // Sanitise config values before injecting into DOM
  function safeText(str) {
    const el = document.createElement("span");
    el.textContent = String(str);
    return el.textContent;
  }
  function safeHref(str) {
    const s = String(str);
    return (s.startsWith("http://") || s.startsWith("https://") || s.endsWith(".html")) ? s : "#";
  }

  const overlay = document.createElement("div");
  overlay.className = "announcement-overlay";

  const modal = document.createElement("div");
  modal.className = "announcement-modal";
  modal.setAttribute("role", "dialog");
  modal.setAttribute("aria-modal", "true");
  modal.setAttribute("aria-labelledby", "announcement-title");

  const head = document.createElement("div");
  head.className = "announcement-head";

  const headText = document.createElement("div");
  const eyebrow = document.createElement("p");
  eyebrow.className = "eyebrow";
  eyebrow.textContent = safeText(announcementConfig.tag);
  const title = document.createElement("h2");
  title.id = "announcement-title";
  title.textContent = safeText(announcementConfig.title);
  headText.append(eyebrow, title);

  const closeBtn = document.createElement("button");
  closeBtn.className = "announcement-close";
  closeBtn.type = "button";
  closeBtn.setAttribute("aria-label", "Close announcement");
  closeBtn.textContent = "×";

  head.append(headText, closeBtn);

  const body = document.createElement("div");
  body.className = "announcement-body";
  announcementConfig.body.forEach((line) => {
    const p = document.createElement("p");
    p.textContent = safeText(line);
    body.appendChild(p);
  });

  const actions = document.createElement("div");
  actions.className = "announcement-actions";
  const primaryLink = document.createElement("a");
  primaryLink.className = "button";
  primaryLink.href = safeHref(announcementConfig.primaryHref);
  primaryLink.textContent = safeText(announcementConfig.primaryLabel);
  const dismissBtn = document.createElement("button");
  dismissBtn.className = "button button-secondary announcement-dismiss";
  dismissBtn.type = "button";
  dismissBtn.textContent = safeText(announcementConfig.secondaryLabel);
  actions.append(primaryLink, dismissBtn);

  modal.append(head, body, actions);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);

  const closeAnnouncement = () => {
    overlay.classList.remove("is-open");
  };

  overlay.querySelector(".announcement-close")?.addEventListener("click", closeAnnouncement);
  overlay.querySelector(".announcement-dismiss")?.addEventListener("click", closeAnnouncement);
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) {
      closeAnnouncement();
    }
  });

  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeAnnouncement();
    }
  });

  window.setTimeout(() => {
    overlay.classList.add("is-open");
  }, reduceMotion ? 0 : 180);
}

if (!reduceMotion) {
  document.body.classList.add("is-entering");
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      document.body.classList.add("is-entering-ready");
      window.setTimeout(() => {
        document.body.classList.remove("is-entering", "is-entering-ready");
      }, 420);
    });
  });

  const revealTargets = document.querySelectorAll(
    ".section .info-card, .section .feature-row, .section .program-detail, .section .coach-card, .section .pricing-card, .section .panel, .section .stat-card, .cta-band"
  );

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12 }
  );

  revealTargets.forEach((element) => {
    element.classList.add("reveal");
    observer.observe(element);
  });

  document.querySelectorAll('a[href$=".html"]').forEach((link) => {
    link.addEventListener("click", (event) => {
      const href = link.getAttribute("href");
      const target = link.getAttribute("target");

      if (!href || target === "_blank" || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
        return;
      }

      if (href.startsWith("http")) {
        return;
      }

      event.preventDefault();
      document.body.classList.add("is-leaving");
      window.setTimeout(() => {
        window.location.href = href;
      }, 260);
    });
  });
}
