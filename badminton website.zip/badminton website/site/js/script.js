const navToggle = document.querySelector(".nav-toggle");
const navLinks = document.querySelector(".nav-links");
const page = document.body.dataset.page;
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const announcementConfig = {
  title: "Club Announcement",
  tag: "Important Update",
  body: [
    "Use this popup for promotions, holiday hours, tournament notices, clinic registration windows, or urgent club updates.",
    "Right now it is set up as a reusable announcement block that appears when a visitor opens any page on the site."
  ],
  primaryLabel: "View Events",
  primaryHref: "events.html",
  secondaryLabel: "Close",
};

if (page) {
  document.querySelector(`[data-nav="${page}"]`)?.classList.add("is-active");
}

if (navToggle && navLinks) {
  navToggle.addEventListener("click", () => {
    const expanded = navToggle.getAttribute("aria-expanded") === "true";
    navToggle.setAttribute("aria-expanded", String(!expanded));
    navLinks.classList.toggle("open", !expanded);
  });

  navLinks.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      navToggle.setAttribute("aria-expanded", "false");
      navLinks.classList.remove("open");
    });
  });
}

document.querySelectorAll("[data-form]").forEach((form) => {
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const success = form.querySelector(".form-success");
    if (success) {
      success.hidden = false;
    }
    form.reset();
  });
});

document.querySelectorAll("[data-external-form]").forEach((form) => {
  form.addEventListener("submit", (event) => {
    const action = form.getAttribute("action") || "";
    if (action.includes("your-form-id")) {
      event.preventDefault();
      const success = form.querySelector(".form-success");
      if (success) {
        success.hidden = false;
      }
    }
  });
});

if (!document.querySelector(".page-transition")) {
  const transitionLayer = document.createElement("div");
  transitionLayer.className = "page-transition";
  document.body.appendChild(transitionLayer);
}

if (page === "pickleball" && !document.querySelector(".announcement-overlay")) {
  const overlay = document.createElement("div");
  overlay.className = "announcement-overlay";
  overlay.innerHTML = `
    <div class="announcement-modal" role="dialog" aria-modal="true" aria-labelledby="announcement-title">
      <div class="announcement-head">
        <div>
          <p class="eyebrow">${announcementConfig.tag}</p>
          <h2 id="announcement-title">${announcementConfig.title}</h2>
        </div>
        <button class="announcement-close" type="button" aria-label="Close announcement">×</button>
      </div>
      <div class="announcement-body">
        ${announcementConfig.body.map((line) => `<p>${line}</p>`).join("")}
      </div>
      <div class="announcement-actions">
        <a class="button" href="${announcementConfig.primaryHref}">${announcementConfig.primaryLabel}</a>
        <button class="button button-secondary announcement-dismiss" type="button">${announcementConfig.secondaryLabel}</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  const closeAnnouncement = () => {
    overlay.classList.remove("is-open");
  };

  overlay.querySelector(".announcement-close")?.addEventListener("click", closeAnnouncement);
  overlay.querySelector(".announcement-dismiss")?.addEventListener("click", closeAnnouncement);
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) {
      closeAnnouncement();
    }
  });

  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeAnnouncement();
    }
  });

  window.setTimeout(() => {
    overlay.classList.add("is-open");
  }, reduceMotion ? 0 : 180);
}

if (!reduceMotion) {
  document.body.classList.add("is-entering");
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      document.body.classList.add("is-entering-ready");
      window.setTimeout(() => {
        document.body.classList.remove("is-entering", "is-entering-ready");
      }, 420);
    });
  });

  const revealTargets = document.querySelectorAll(
    ".section .info-card, .section .feature-row, .section .program-detail, .section .coach-card, .section .pricing-card, .section .panel, .section .stat-card, .cta-band"
  );

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12 }
  );

  revealTargets.forEach((element) => {
    element.classList.add("reveal");
    observer.observe(element);
  });

  document.querySelectorAll('a[href$=".html"]').forEach((link) => {
    link.addEventListener("click", (event) => {
      const href = link.getAttribute("href");
      const target = link.getAttribute("target");

      if (!href || target === "_blank" || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
        return;
      }

      if (href.startsWith("http")) {
        return;
      }

      event.preventDefault();
      document.body.classList.add("is-leaving");
      window.setTimeout(() => {
        window.location.href = href;
      }, 260);
    });
  });
}
